ALTER TABLE `areatrigger_graveyard`
    CHANGE `id` `id` int(11) unsigned NOT NULL auto_increment COMMENT 'Identifier';

