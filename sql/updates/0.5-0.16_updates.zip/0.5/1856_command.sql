insert into command values('shutdown','3','Syntax: .shutdown seconds');
insert into command values('cshutdown','3','Syntax: .cshutdown Cancels shuttdown');

