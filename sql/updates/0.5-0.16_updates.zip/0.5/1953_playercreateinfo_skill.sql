ALTER IGNORE TABLE `playercreateinfo_skill`
    ADD PRIMARY KEY (`createid`,`Skill`);

