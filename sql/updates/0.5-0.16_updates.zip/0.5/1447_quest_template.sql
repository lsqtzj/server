ALTER TABLE `quest_template`
    CHANGE `Title`          `Title`          text,
    CHANGE `Details`        `Details`        text,
    CHANGE `Objectives`     `Objectives`     text,
    CHANGE `CompletionText` `CompletionText` text,
    CHANGE `IncompleteText` `IncompleteText` text,
    CHANGE `EndText`        `EndText`        text,
    CHANGE `ObjectiveText1` `ObjectiveText1` text,
    CHANGE `ObjectiveText2` `ObjectiveText2` text,
    CHANGE `ObjectiveText3` `ObjectiveText3` text,
    CHANGE `ObjectiveText4` `ObjectiveText4` text;
