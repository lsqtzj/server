UPDATE command SET `help` = 'Syntax: .addmove [#waittime]\r\n\r\nAdd your current location as a waypoint for the selected creature. And optional add wait time.' WHERE `name` = 'addmove';
