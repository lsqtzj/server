DELETE FROM `spell_learn_spell` WHERE `SpellID` IN ( 2480, 7918, 7919 );
