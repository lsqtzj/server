DELETE FROM `spell_learn_skill` WHERE `entry` IN ( 3386 );
