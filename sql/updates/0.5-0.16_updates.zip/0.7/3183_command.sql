INSERT INTO `command` VALUES('lookupitemset',3,'Syntax: .lookupitemset $itemname\r\n\r\nLooks up an item set by $itemname, and returns all matches with their Item set ID\'s.');
