UPDATE `playercreateinfo_spell`
  SET `Spell` = 5420 WHERE `Spell` = 3122;
