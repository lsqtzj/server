alter table `character` add column `rename` tinyint (3) UNSIGNED DEFAULT '0' NOT NULL after `stable_slots`;
