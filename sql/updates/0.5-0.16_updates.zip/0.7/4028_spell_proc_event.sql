DELETE FROM `spell_proc_event` WHERE `entry` IN ( 15600 );
INSERT INTO `spell_proc_event` VALUES
(15600,0,0,0,0,1,3);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 33142, 33145, 33146 );
INSERT INTO `spell_proc_event` VALUES
(33142,0,0,0,0,8658944,0),
(33145,0,0,0,0,8658944,0),
(33146,0,0,0,0,8658944,0);


DELETE FROM `spell_proc_event` WHERE `entry` IN ( 27179 );
INSERT INTO `spell_proc_event` VALUES
(27179,0,0,0,0,64,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 37443 );
INSERT INTO `spell_proc_event` VALUES
(37443,0,0,0,0,16384,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 34774 );
INSERT INTO `spell_proc_event` VALUES
(34774,0,0,0,0,524289,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 34950, 34954 );
INSERT INTO `spell_proc_event` VALUES
(34950,0,0,0,0,4194304,0),
(34954,0,0,0,0,4194304,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 34506, 34507, 34508, 34838, 34839 );
INSERT INTO `spell_proc_event` VALUES
(34506,0,0,0,0,524288,0),
(34507,0,0,0,0,524288,0),
(34508,0,0,0,0,524288,0),
(34838,0,0,0,0,524288,0),
(34839,0,0,0,0,524288,0);
