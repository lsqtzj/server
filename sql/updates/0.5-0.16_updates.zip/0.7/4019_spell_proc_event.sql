DELETE FROM `spell_proc_event` WHERE `entry` IN ( 17106, 17107, 17108 );
INSERT INTO `spell_proc_event` VALUES
(17106,0,0,0,0,16384,0),
(17107,0,0,0,0,16384,0),
(17108,0,0,0,0,16384,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 34303 );
INSERT INTO `spell_proc_event` VALUES
(34303,0,0,0,0,128,0);
