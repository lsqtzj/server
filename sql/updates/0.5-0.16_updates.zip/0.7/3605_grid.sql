DROP TABLE IF EXISTS `corpse_grid`;
DROP TABLE IF EXISTS `creature_grid`;
DROP TABLE IF EXISTS `gameobject_grid`;
