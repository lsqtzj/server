ALTER TABLE `character_pet`
  ADD COLUMN `curhealth` int(11) unsigned NOT NULL default '1',
  ADD COLUMN `curmana` int(11) unsigned NOT NULL default '0';
