DELETE FROM `spell_chain` WHERE `spell_id` IN (33736);

INSERT INTO `spell_chain` VALUES
(33736,24398,24398,2);