delete from `spell_proc_event` where `entry` = 23547;
insert into `spell_proc_event` values(23547,0,0,0,0,32,0);
