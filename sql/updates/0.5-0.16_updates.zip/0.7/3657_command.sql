DELETE FROM `command` WHERE `name` = 'NewMail' OR `name` = 'QNM';
