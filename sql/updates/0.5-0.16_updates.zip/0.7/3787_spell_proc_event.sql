REPLACE INTO `spell_proc_event` VALUES (1120, 0, 0, 0, 0, 4, 0);
REPLACE INTO `spell_proc_event` VALUES (8288, 0, 0, 0, 0, 4, 0);
REPLACE INTO `spell_proc_event` VALUES (8289, 0, 0, 0, 0, 4, 0);
REPLACE INTO `spell_proc_event` VALUES (11675, 0, 0, 0, 0, 4, 0);
REPLACE INTO `spell_proc_event` VALUES (27217, 0, 0, 0, 0, 4, 0);
REPLACE INTO `spell_proc_event` VALUES (24932, 0, 0, 0, 0, 4096, 0);
REPLACE INTO `spell_proc_event` VALUES (31641, 0, 0, 0, 0, 524290, 0);
REPLACE INTO `spell_proc_event` VALUES (31642, 0, 0, 0, 0, 524290, 0);
