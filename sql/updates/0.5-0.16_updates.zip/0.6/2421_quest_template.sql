ALTER TABLE `quest_template`
     ADD `DetailsEmote` int(11) NOT NULL default '0',
     ADD `IncompleteEmote` int(11) NOT NULL default '0',
     ADD `CompleteEmote` int(11) NOT NULL default '0';
