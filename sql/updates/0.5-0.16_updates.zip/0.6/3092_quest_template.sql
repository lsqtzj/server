ALTER TABLE `quest_template` CHANGE `PrevQuestId` `PrevQuestId` int(11) NOT NULL default '0';
ALTER TABLE `quest_template` CHANGE `NextQuestId` `NextQuestId` int(11) NOT NULL default '0';