ALTER TABLE `character`
    ADD `resettalents_cost` int(11) unsigned NOT NULL default '0',
    ADD `resettalents_time` bigint(20) unsigned NOT NULL default '0';
