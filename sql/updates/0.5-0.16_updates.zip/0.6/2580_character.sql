ALTER TABLE `character`
  ADD `instanceid` int(11) unsigned NOT NULL default '0' AFTER `map`;
