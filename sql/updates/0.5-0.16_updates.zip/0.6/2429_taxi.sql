DROP TABLE IF EXISTS `taxi_node`;
DROP TABLE IF EXISTS `taxi_path`;
DROP TABLE IF EXISTS `taxi_pathnode`;
