UPDATE `spell_proc_event` set `procFlags`=524288 where `entry` in (5638, 5639, 5640, 5641, 5642, 5643, 5751, 5752, 5753, 5754, 5755, 5756);
