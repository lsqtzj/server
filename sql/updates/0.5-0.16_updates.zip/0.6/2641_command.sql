INSERT INTO `command` VALUES('lookupmob',3,'Syntax: .lookupmob $namepart\r\n\r\nLooks up a creature by $namepart, and returns all matches with their creature ID\'s.');
INSERT INTO `command` VALUES('lookupskill',3,'Syntax: .lookupskill $$namepart\r\n\r\nLooks up a skill by $namepart, and returns all matches with their skill ID\'s.');
