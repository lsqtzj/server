ALTER TABLE `creature`
    DROP `npcflags`,
    DROP `faction`;
