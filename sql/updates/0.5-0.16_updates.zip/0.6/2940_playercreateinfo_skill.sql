DELETE FROM `playercreateinfo_skill` WHERE `Skill` = 633;
