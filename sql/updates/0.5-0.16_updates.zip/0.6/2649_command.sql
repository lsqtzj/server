INSERT INTO `command` VALUES('saveall',1,'Syntax: .saveallr\n\r\nSave all characters in game.');

