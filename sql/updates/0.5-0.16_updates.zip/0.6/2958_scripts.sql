ALTER TABLE `scripts`
  CHANGE COLUMN `datatext` `datatext` text NOT NULL;
